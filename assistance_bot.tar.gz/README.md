# assistance_bot

This bot uses latitude and longitude shows the temperature
